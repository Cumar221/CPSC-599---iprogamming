//
//  SPTConnectButton.h
//  Spotify iOS SDK
//
//  Created by Daniel Kennett on 2013-09-10.

#import <UIKit/UIKit.h>

@interface SPTConnectButton : UIControl
@end
